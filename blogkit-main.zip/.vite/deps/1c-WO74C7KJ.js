import {
  require_c
} from "./chunk-BZ43TZPQ.js";
import "./chunk-CEQRFMJQ.js";
export default require_c();
//# sourceMappingURL=1c-WO74C7KJ.js.map
