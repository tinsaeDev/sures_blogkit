import {
  require_armasm
} from "./chunk-AV67YWRM.js";
import "./chunk-CEQRFMJQ.js";
export default require_armasm();
//# sourceMappingURL=armasm-ATGHEGMF.js.map
