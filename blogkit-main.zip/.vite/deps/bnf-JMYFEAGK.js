import {
  require_bnf
} from "./chunk-OKXDYC6G.js";
import "./chunk-CEQRFMJQ.js";
export default require_bnf();
//# sourceMappingURL=bnf-JMYFEAGK.js.map
