import {
  require_basic
} from "./chunk-XWOW7WK2.js";
import "./chunk-CEQRFMJQ.js";
export default require_basic();
//# sourceMappingURL=basic-FBV4PXA6.js.map
