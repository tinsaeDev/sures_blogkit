import {
  require_asciidoc
} from "./chunk-IJTSFRA5.js";
import "./chunk-CEQRFMJQ.js";
export default require_asciidoc();
//# sourceMappingURL=asciidoc-AYERNGKF.js.map
