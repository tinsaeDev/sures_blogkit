import {
  require_c
} from "./chunk-BRQA5GOZ.js";
import "./chunk-CEQRFMJQ.js";
export default require_c();
//# sourceMappingURL=c-D5Z67GVI.js.map
