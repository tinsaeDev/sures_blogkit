import {
  require_cal
} from "./chunk-YLGC47SC.js";
import "./chunk-CEQRFMJQ.js";
export default require_cal();
//# sourceMappingURL=cal-6HVP7E3N.js.map
