import {
  require_birb
} from "./chunk-PYKVLQ2T.js";
import "./chunk-CEQRFMJQ.js";
export default require_birb();
//# sourceMappingURL=birb-LMTALQUU.js.map
