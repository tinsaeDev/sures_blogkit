import {
  require_cfscript
} from "./chunk-B4PE6DHY.js";
import "./chunk-CEQRFMJQ.js";
export default require_cfscript();
//# sourceMappingURL=cfscript-XMS2U6ZC.js.map
