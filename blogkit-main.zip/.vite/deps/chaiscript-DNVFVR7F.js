import {
  require_chaiscript
} from "./chunk-KOYTL6HT.js";
import "./chunk-2RL3G3RW.js";
import "./chunk-44FPENME.js";
import "./chunk-CEQRFMJQ.js";
export default require_chaiscript();
//# sourceMappingURL=chaiscript-DNVFVR7F.js.map
