import {
  require_arff
} from "./chunk-LPTGPOEO.js";
import "./chunk-CEQRFMJQ.js";
export default require_arff();
//# sourceMappingURL=arff-DUGE4FAW.js.map
