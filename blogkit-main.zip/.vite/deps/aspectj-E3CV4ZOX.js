import {
  require_aspectj
} from "./chunk-RT2EN5KO.js";
import "./chunk-CEQRFMJQ.js";
export default require_aspectj();
//# sourceMappingURL=aspectj-E3CV4ZOX.js.map
