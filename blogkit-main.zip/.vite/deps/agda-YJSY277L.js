import {
  require_agda
} from "./chunk-5QEEV5OI.js";
import "./chunk-CEQRFMJQ.js";
export default require_agda();
//# sourceMappingURL=agda-YJSY277L.js.map
