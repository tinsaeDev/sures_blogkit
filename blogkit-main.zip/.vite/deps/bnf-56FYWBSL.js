import {
  require_bnf
} from "./chunk-SOGECOSC.js";
import "./chunk-CEQRFMJQ.js";
export default require_bnf();
//# sourceMappingURL=bnf-56FYWBSL.js.map
