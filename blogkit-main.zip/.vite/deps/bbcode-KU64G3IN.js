import {
  require_bbcode
} from "./chunk-J6ZR7HY5.js";
import "./chunk-CEQRFMJQ.js";
export default require_bbcode();
//# sourceMappingURL=bbcode-KU64G3IN.js.map
