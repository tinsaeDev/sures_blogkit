import {
  require_bash
} from "./chunk-Q5JMI2YV.js";
import "./chunk-CEQRFMJQ.js";
export default require_bash();
//# sourceMappingURL=bash-YK4CUBRR.js.map
