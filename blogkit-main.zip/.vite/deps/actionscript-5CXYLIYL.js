import {
  require_actionscript
} from "./chunk-VIXBRQ7V.js";
import "./chunk-CEQRFMJQ.js";
export default require_actionscript();
//# sourceMappingURL=actionscript-5CXYLIYL.js.map
