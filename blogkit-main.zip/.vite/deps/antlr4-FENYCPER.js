import {
  require_antlr4
} from "./chunk-P4GDKEOM.js";
import "./chunk-CEQRFMJQ.js";
export default require_antlr4();
//# sourceMappingURL=antlr4-FENYCPER.js.map
