import {
  require_apl
} from "./chunk-UNTPQDB7.js";
import "./chunk-CEQRFMJQ.js";
export default require_apl();
//# sourceMappingURL=apl-C3ABPVSX.js.map
