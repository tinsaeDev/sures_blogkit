import {
  require_angelscript
} from "./chunk-QSTF7O2B.js";
import "./chunk-CEQRFMJQ.js";
export default require_angelscript();
//# sourceMappingURL=angelscript-QUTX6HMU.js.map
