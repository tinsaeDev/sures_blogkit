import {
  require_asmatmel
} from "./chunk-YFDMVLTQ.js";
import "./chunk-CEQRFMJQ.js";
export default require_asmatmel();
//# sourceMappingURL=asmatmel-7USWH3SG.js.map
