import {
  require_autoit
} from "./chunk-FBXUVPU2.js";
import "./chunk-CEQRFMJQ.js";
export default require_autoit();
//# sourceMappingURL=autoit-ZDI4AQRO.js.map
