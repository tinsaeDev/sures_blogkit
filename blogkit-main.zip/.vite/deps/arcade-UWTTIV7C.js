import {
  require_arcade
} from "./chunk-DBEP4GWC.js";
import "./chunk-CEQRFMJQ.js";
export default require_arcade();
//# sourceMappingURL=arcade-UWTTIV7C.js.map
