import {
  require_bison
} from "./chunk-WKX5K3GR.js";
import "./chunk-44FPENME.js";
import "./chunk-CEQRFMJQ.js";
export default require_bison();
//# sourceMappingURL=bison-HSIFQGMP.js.map
