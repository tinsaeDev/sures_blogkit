import {
  require_asm6502
} from "./chunk-FNOFZACN.js";
import "./chunk-CEQRFMJQ.js";
export default require_asm6502();
//# sourceMappingURL=asm6502-JU33FUGH.js.map
