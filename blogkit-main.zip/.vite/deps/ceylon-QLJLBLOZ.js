import {
  require_ceylon
} from "./chunk-42CIDTPK.js";
import "./chunk-CEQRFMJQ.js";
export default require_ceylon();
//# sourceMappingURL=ceylon-QLJLBLOZ.js.map
