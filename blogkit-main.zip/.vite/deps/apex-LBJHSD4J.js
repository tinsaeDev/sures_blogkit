import {
  require_apex
} from "./chunk-MD2NZNSC.js";
import "./chunk-VJOICHI4.js";
import "./chunk-CEQRFMJQ.js";
export default require_apex();
//# sourceMappingURL=apex-LBJHSD4J.js.map
