import {
  require_applescript
} from "./chunk-DE62CHKZ.js";
import "./chunk-CEQRFMJQ.js";
export default require_applescript();
//# sourceMappingURL=applescript-BQ777THF.js.map
