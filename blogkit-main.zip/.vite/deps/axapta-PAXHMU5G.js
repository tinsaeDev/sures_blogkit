import {
  require_axapta
} from "./chunk-S5BVLX3R.js";
import "./chunk-CEQRFMJQ.js";
export default require_axapta();
//# sourceMappingURL=axapta-PAXHMU5G.js.map
