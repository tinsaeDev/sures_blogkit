import {
  require_avrasm
} from "./chunk-6Y7S2XVZ.js";
import "./chunk-CEQRFMJQ.js";
export default require_avrasm();
//# sourceMappingURL=avrasm-W2T3V4A3.js.map
