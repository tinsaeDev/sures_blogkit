import {
  require_awk
} from "./chunk-YTJIBYBT.js";
import "./chunk-CEQRFMJQ.js";
export default require_awk();
//# sourceMappingURL=awk-XBE6YB6I.js.map
