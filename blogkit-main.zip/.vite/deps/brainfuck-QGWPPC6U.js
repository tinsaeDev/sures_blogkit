import {
  require_brainfuck
} from "./chunk-COXXZBQD.js";
import "./chunk-CEQRFMJQ.js";
export default require_brainfuck();
//# sourceMappingURL=brainfuck-QGWPPC6U.js.map
