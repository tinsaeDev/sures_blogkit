import {
  require_autohotkey
} from "./chunk-YBYOTJUC.js";
import "./chunk-CEQRFMJQ.js";
export default require_autohotkey();
//# sourceMappingURL=autohotkey-56IBKEJN.js.map
