import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/highlight.js/lib/languages/plaintext.js
var require_plaintext = __commonJS({
  "node_modules/highlight.js/lib/languages/plaintext.js"(exports, module) {
    function plaintext(hljs) {
      return {
        name: "Plain text",
        aliases: [
          "text",
          "txt"
        ],
        disableAutodetect: true
      };
    }
    module.exports = plaintext;
  }
});

export {
  require_plaintext
};
//# sourceMappingURL=chunk-SWRYFPLF.js.map
