import {
  require_bsl
} from "./chunk-HHF5L6MV.js";
import "./chunk-CEQRFMJQ.js";
export default require_bsl();
//# sourceMappingURL=bsl-J6D4BADX.js.map
