import {
  require_applescript
} from "./chunk-FW3XCAIA.js";
import "./chunk-CEQRFMJQ.js";
export default require_applescript();
//# sourceMappingURL=applescript-C5WF4L7S.js.map
