import {
  require_aql
} from "./chunk-F6EDU3KZ.js";
import "./chunk-CEQRFMJQ.js";
export default require_aql();
//# sourceMappingURL=aql-6SQGOTEG.js.map
