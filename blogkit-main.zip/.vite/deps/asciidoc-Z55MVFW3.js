import {
  require_asciidoc
} from "./chunk-M2YZHHFE.js";
import "./chunk-CEQRFMJQ.js";
export default require_asciidoc();
//# sourceMappingURL=asciidoc-Z55MVFW3.js.map
