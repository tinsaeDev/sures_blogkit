import {
  require_aspnet
} from "./chunk-5DOGEVMM.js";
import "./chunk-7BCG4JFI.js";
import "./chunk-CEQRFMJQ.js";
export default require_aspnet();
//# sourceMappingURL=aspnet-UQCZTHWY.js.map
