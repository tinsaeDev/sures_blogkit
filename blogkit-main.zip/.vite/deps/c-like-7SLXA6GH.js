import {
  require_c_like
} from "./chunk-NB6DVZ2H.js";
import "./chunk-CEQRFMJQ.js";
export default require_c_like();
//# sourceMappingURL=c-like-7SLXA6GH.js.map
