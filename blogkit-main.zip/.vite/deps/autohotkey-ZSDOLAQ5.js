import {
  require_autohotkey
} from "./chunk-GEHWQG6P.js";
import "./chunk-CEQRFMJQ.js";
export default require_autohotkey();
//# sourceMappingURL=autohotkey-ZSDOLAQ5.js.map
