import {
  require_abnf
} from "./chunk-M4CIUN6N.js";
import "./chunk-CEQRFMJQ.js";
export default require_abnf();
//# sourceMappingURL=abnf-HNXV34F5.js.map
