import {
  require_ada
} from "./chunk-SLW54Q2D.js";
import "./chunk-CEQRFMJQ.js";
export default require_ada();
//# sourceMappingURL=ada-DQ7NQGOU.js.map
