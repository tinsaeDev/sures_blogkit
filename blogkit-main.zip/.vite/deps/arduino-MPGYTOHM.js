import {
  require_arduino
} from "./chunk-INONCUUC.js";
import "./chunk-CEQRFMJQ.js";
export default require_arduino();
//# sourceMappingURL=arduino-MPGYTOHM.js.map
