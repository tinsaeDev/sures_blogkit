import {
  require_actionscript
} from "./chunk-G5USZTOO.js";
import "./chunk-CEQRFMJQ.js";
export default require_actionscript();
//# sourceMappingURL=actionscript-27FZ4KML.js.map
