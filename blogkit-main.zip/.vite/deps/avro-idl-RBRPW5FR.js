import {
  require_avro_idl
} from "./chunk-3JYKYZ7N.js";
import "./chunk-CEQRFMJQ.js";
export default require_avro_idl();
//# sourceMappingURL=avro-idl-RBRPW5FR.js.map
