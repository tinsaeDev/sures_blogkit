import {
  require_bash
} from "./chunk-QAMAUWU5.js";
import "./chunk-CEQRFMJQ.js";
export default require_bash();
//# sourceMappingURL=bash-FX44VU57.js.map
