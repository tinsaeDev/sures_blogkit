import {
  require_brightscript
} from "./chunk-2QFSUQ4R.js";
import "./chunk-CEQRFMJQ.js";
export default require_brightscript();
//# sourceMappingURL=brightscript-JOSKLUK4.js.map
