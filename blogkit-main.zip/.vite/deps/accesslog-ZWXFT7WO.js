import {
  require_accesslog
} from "./chunk-EAMEC23E.js";
import "./chunk-CEQRFMJQ.js";
export default require_accesslog();
//# sourceMappingURL=accesslog-ZWXFT7WO.js.map
