import {
  require_image_url_umd
} from "./chunk-27I7EFQB.js";
import "./chunk-CEQRFMJQ.js";
export default require_image_url_umd();
//# sourceMappingURL=@sanity_image-url.js.map
