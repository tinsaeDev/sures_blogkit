import {
  require_bicep
} from "./chunk-UF4OUKMN.js";
import "./chunk-CEQRFMJQ.js";
export default require_bicep();
//# sourceMappingURL=bicep-7TZSL5KZ.js.map
