import {
  require_c
} from "./chunk-44FPENME.js";
import "./chunk-CEQRFMJQ.js";
export default require_c();
//# sourceMappingURL=c-JUBKF6CJ.js.map
