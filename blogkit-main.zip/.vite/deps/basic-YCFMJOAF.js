import {
  require_basic
} from "./chunk-O4A567YB.js";
import "./chunk-CEQRFMJQ.js";
export default require_basic();
//# sourceMappingURL=basic-YCFMJOAF.js.map
