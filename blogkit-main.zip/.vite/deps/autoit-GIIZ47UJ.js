import {
  require_autoit
} from "./chunk-CYW7U3OI.js";
import "./chunk-CEQRFMJQ.js";
export default require_autoit();
//# sourceMappingURL=autoit-GIIZ47UJ.js.map
