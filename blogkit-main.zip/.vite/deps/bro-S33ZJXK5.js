import {
  require_bro
} from "./chunk-3DKKS7ET.js";
import "./chunk-CEQRFMJQ.js";
export default require_bro();
//# sourceMappingURL=bro-S33ZJXK5.js.map
