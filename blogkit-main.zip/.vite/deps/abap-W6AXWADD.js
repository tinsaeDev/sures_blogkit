import {
  require_abap
} from "./chunk-I24BDREZ.js";
import "./chunk-CEQRFMJQ.js";
export default require_abap();
//# sourceMappingURL=abap-W6AXWADD.js.map
