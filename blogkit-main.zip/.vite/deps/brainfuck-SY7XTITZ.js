import {
  require_brainfuck
} from "./chunk-7I6GBVNQ.js";
import "./chunk-CEQRFMJQ.js";
export default require_brainfuck();
//# sourceMappingURL=brainfuck-SY7XTITZ.js.map
