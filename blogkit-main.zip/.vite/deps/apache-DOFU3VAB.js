import {
  require_apache
} from "./chunk-YJHB7ZBQ.js";
import "./chunk-CEQRFMJQ.js";
export default require_apache();
//# sourceMappingURL=apache-DOFU3VAB.js.map
