import {
  require_batch
} from "./chunk-OXMV43SD.js";
import "./chunk-CEQRFMJQ.js";
export default require_batch();
//# sourceMappingURL=batch-27UAN7L2.js.map
