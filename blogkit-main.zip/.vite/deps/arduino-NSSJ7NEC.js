import {
  require_arduino
} from "./chunk-U337EEW7.js";
import "./chunk-2RL3G3RW.js";
import "./chunk-44FPENME.js";
import "./chunk-CEQRFMJQ.js";
export default require_arduino();
//# sourceMappingURL=arduino-NSSJ7NEC.js.map
