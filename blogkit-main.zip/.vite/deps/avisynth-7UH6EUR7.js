import {
  require_avisynth
} from "./chunk-6NFV4673.js";
import "./chunk-CEQRFMJQ.js";
export default require_avisynth();
//# sourceMappingURL=avisynth-7UH6EUR7.js.map
