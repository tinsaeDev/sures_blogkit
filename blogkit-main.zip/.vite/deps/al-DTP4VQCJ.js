import {
  require_al
} from "./chunk-UQWTP3NR.js";
import "./chunk-CEQRFMJQ.js";
export default require_al();
//# sourceMappingURL=al-DTP4VQCJ.js.map
