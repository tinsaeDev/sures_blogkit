import {
  require_capnproto
} from "./chunk-6BDJCSPJ.js";
import "./chunk-CEQRFMJQ.js";
export default require_capnproto();
//# sourceMappingURL=capnproto-KKV5ZPXE.js.map
